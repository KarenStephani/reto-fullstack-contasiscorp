using Contasiscorp.Application.DTOs;
using Contasiscorp.Application.Mappers;
using Contasiscorp.Application.Validators;
using Contasiscorp.Domain.Enums;
using Contasiscorp.Infrastructure.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace Contasiscorp.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ComprobantesController : ControllerBase
{
    private readonly IComprobanteRepository _repository;
    private readonly ILogger<ComprobantesController> _logger;

    public ComprobantesController(
        IComprobanteRepository repository,
        ILogger<ComprobantesController> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    [HttpGet]
    [ProducesResponseType(typeof(PaginatedResponse<ComprobanteListDto>), StatusCodes.Status200OK)]
    public async Task<ActionResult<PaginatedResponse<ComprobanteListDto>>> GetComprobantes(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 10,
        [FromQuery] DateTime? fechaDesde = null,
        [FromQuery] DateTime? fechaHasta = null,
        [FromQuery] string? tipo = null,
        [FromQuery] string? rucReceptor = null,
        [FromQuery] string? estado = null)
    {
        ComprobanteTipo? tipoEnum = null;
        if (!string.IsNullOrEmpty(tipo) && Enum.TryParse<ComprobanteTipo>(tipo, out var parsedTipo))
            tipoEnum = parsedTipo;

        ComprobanteEstado? estadoEnum = null;
        if (!string.IsNullOrEmpty(estado) && Enum.TryParse<ComprobanteEstado>(estado, out var parsedEstado))
            estadoEnum = parsedEstado;

        var (items, total) = await _repository.GetPagedAsync(
            page, pageSize, fechaDesde, fechaHasta, tipoEnum, rucReceptor, estadoEnum);

        var response = new PaginatedResponse<ComprobanteListDto>
        {
            Items = items.Select(ComprobanteMapper.ToListDto).ToList(),
            Total = total,
            Page = page,
            PageSize = pageSize
        };

        return Ok(response);
    }

    [HttpGet("{id}")]
    [ProducesResponseType(typeof(ComprobanteResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ComprobanteResponseDto>> GetComprobante(Guid id)
    {
        var comprobante = await _repository.GetByIdAsync(id);
        if (comprobante == null)
            return NotFound(new { message = $"Comprobante {id} no encontrado" });

        return Ok(ComprobanteMapper.ToResponseDto(comprobante));
    }

    [HttpPost]
    [ProducesResponseType(typeof(ComprobanteResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ComprobanteResponseDto>> CreateComprobante(
        [FromBody] CreateComprobanteDto dto)
    {
        var validator = new CreateComprobanteDtoValidator();
        var validationResult = await validator.ValidateAsync(dto);

        if (!validationResult.IsValid)
        {
            return BadRequest(new
            {
                errors = validationResult.Errors.Select(e => new
                {
                    property = e.PropertyName,
                    message = e.ErrorMessage
                })
            });
        }

        var numero = await _repository.GetNextNumeroAsync(dto.Serie);
        var comprobante = ComprobanteMapper.ToDomain(dto, numero);

        try
        {
            comprobante.Validate();
            await _repository.AddAsync(comprobante);

            _logger.LogInformation("Comprobante creado: {Serie}-{Numero}", comprobante.Serie, comprobante.Numero);

            var response = ComprobanteMapper.ToResponseDto(comprobante);
            return CreatedAtAction(nameof(GetComprobante), new { id = comprobante.Id }, response);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Error de validación al crear comprobante");
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}/anular")]
    [ProducesResponseType(typeof(ComprobanteResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ComprobanteResponseDto>> AnularComprobante(Guid id)
    {
        var comprobante = await _repository.GetByIdAsync(id);
        if (comprobante == null)
            return NotFound(new { message = $"Comprobante {id} no encontrado" });

        try
        {
            comprobante.Anular();
            await _repository.UpdateAsync(comprobante);

            _logger.LogInformation("Comprobante anulado: {Id}", id);

            return Ok(ComprobanteMapper.ToResponseDto(comprobante));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error al anular comprobante {Id}", id);
            return BadRequest(new { message = ex.Message });
        }
    }
}
