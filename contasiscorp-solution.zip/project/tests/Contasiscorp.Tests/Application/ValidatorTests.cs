using Contasiscorp.Application.DTOs;
using Contasiscorp.Application.Validators;
using FluentAssertions;
using Xunit;

namespace Contasiscorp.Tests.Application;

public class ValidatorTests
{
    private readonly CreateComprobanteDtoValidator _validator;

    public ValidatorTests()
    {
        _validator = new CreateComprobanteDtoValidator();
    }

    [Fact]
    public async Task Validator_Succeeds_WithValidFactura()
    {
        var dto = CreateValidFacturaDto();

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeTrue();
    }

    [Fact]
    public async Task Validator_Fails_WhenTipoIsInvalid()
    {
        var dto = CreateValidFacturaDto();
        dto.Tipo = "Invalido";

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == "Tipo");
    }

    [Fact]
    public async Task Validator_Fails_WhenRucEmisorIsInvalid()
    {
        var dto = CreateValidFacturaDto();
        dto.RucEmisor = "123";

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == "RucEmisor");
    }

    [Fact]
    public async Task Validator_Fails_WhenFacturaHasNoRucReceptor()
    {
        var dto = CreateValidFacturaDto();
        dto.RucReceptor = null;

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == "RucReceptor");
    }

    [Fact]
    public async Task Validator_Fails_WhenSerieFormatIsWrong()
    {
        var dto = CreateValidFacturaDto();
        dto.Serie = "B001";

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == "Serie");
    }

    [Fact]
    public async Task Validator_Fails_WhenNoItems()
    {
        var dto = CreateValidFacturaDto();
        dto.Items = new List<ComprobanteItemDto>();

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeFalse();
        result.Errors.Should().Contain(e => e.PropertyName == "Items");
    }

    [Fact]
    public async Task Validator_Succeeds_WithValidBoleta()
    {
        var dto = new CreateComprobanteDto
        {
            Tipo = "Boleta",
            Serie = "B001",
            RucEmisor = "20123456789",
            RazonSocialEmisor = "Empresa Test SAC",
            Items = new List<ComprobanteItemDto>
            {
                new ComprobanteItemDto
                {
                    Descripcion = "Producto Test",
                    Cantidad = 1,
                    PrecioUnitario = 100
                }
            }
        };

        var result = await _validator.ValidateAsync(dto);

        result.IsValid.Should().BeTrue();
    }

    private static CreateComprobanteDto CreateValidFacturaDto()
    {
        return new CreateComprobanteDto
        {
            Tipo = "Factura",
            Serie = "F001",
            RucEmisor = "20123456789",
            RazonSocialEmisor = "Empresa Test SAC",
            RucReceptor = "20987654321",
            RazonSocialReceptor = "Cliente Test SAC",
            Items = new List<ComprobanteItemDto>
            {
                new ComprobanteItemDto
                {
                    Descripcion = "Producto Test",
                    Cantidad = 1,
                    PrecioUnitario = 100
                }
            }
        };
    }
}
