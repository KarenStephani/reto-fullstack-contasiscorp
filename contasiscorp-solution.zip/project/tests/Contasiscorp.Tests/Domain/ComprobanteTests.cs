using Contasiscorp.Domain.Entities;
using Contasiscorp.Domain.Enums;
using Contasiscorp.Domain.Exceptions;
using FluentAssertions;
using Xunit;

namespace Contasiscorp.Tests.Domain;

public class ComprobanteTests
{
    [Fact]
    public void Comprobante_CalculatesSubTotalCorrectly()
    {
        var comprobante = CreateValidFactura();

        comprobante.SubTotal.Should().Be(100m);
    }

    [Fact]
    public void Comprobante_CalculatesIGVCorrectly()
    {
        var comprobante = CreateValidFactura();

        comprobante.IGV.Should().Be(18m);
    }

    [Fact]
    public void Comprobante_CalculatesTotalCorrectly()
    {
        var comprobante = CreateValidFactura();

        comprobante.Total.Should().Be(118m);
    }

    [Fact]
    public void Anular_ChangesEstadoToAnulado()
    {
        var comprobante = CreateValidFactura();

        comprobante.Anular();

        comprobante.Estado.Should().Be(ComprobanteEstado.Anulado);
    }

    [Fact]
    public void Anular_ThrowsException_WhenAlreadyAnulado()
    {
        var comprobante = CreateValidFactura();
        comprobante.Anular();

        var act = () => comprobante.Anular();

        act.Should().Throw<ComprobanteAlreadyAnuladoException>();
    }

    [Fact]
    public void Validate_ThrowsException_WhenRucEmisorIsInvalid()
    {
        var comprobante = CreateValidFactura();
        comprobante.RucEmisor = "123";

        var act = () => comprobante.Validate();

        act.Should().Throw<ArgumentException>()
            .WithMessage("*11 dígitos*");
    }

    [Fact]
    public void Validate_ThrowsException_WhenFacturaHasNoRucReceptor()
    {
        var comprobante = CreateValidFactura();
        comprobante.RucReceptor = null;

        var act = () => comprobante.Validate();

        act.Should().Throw<ArgumentException>();
    }

    [Fact]
    public void Validate_ThrowsException_WhenSerieFormatIsInvalid()
    {
        var comprobante = CreateValidFactura();
        comprobante.Serie = "B001";

        var act = () => comprobante.Validate();

        act.Should().Throw<ArgumentException>()
            .WithMessage("*formato de serie*");
    }

    [Fact]
    public void Validate_ThrowsException_WhenNoItems()
    {
        var comprobante = CreateValidFactura();
        comprobante.Items.Clear();

        var act = () => comprobante.Validate();

        act.Should().Throw<ArgumentException>()
            .WithMessage("*al menos un item*");
    }

    private static Comprobante CreateValidFactura()
    {
        return new Comprobante
        {
            Tipo = ComprobanteTipo.Factura,
            Serie = "F001",
            Numero = 1,
            FechaEmision = DateTime.UtcNow,
            RucEmisor = "20123456789",
            RazonSocialEmisor = "Empresa Test SAC",
            RucReceptor = "20987654321",
            RazonSocialReceptor = "Cliente Test SAC",
            Items = new List<ComprobanteItem>
            {
                new ComprobanteItem
                {
                    Descripcion = "Producto Test",
                    Cantidad = 2,
                    PrecioUnitario = 50
                }
            }
        };
    }
}
