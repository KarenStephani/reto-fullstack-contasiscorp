namespace Contasiscorp.Domain.Enums;

public enum EstadoComprobante
{
    Borrador = 1,
    Emitido = 2,
    Anulado = 3,
    Rechazado = 4
}
