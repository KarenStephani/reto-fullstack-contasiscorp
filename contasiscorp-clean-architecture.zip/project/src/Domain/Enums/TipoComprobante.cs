namespace Contasiscorp.Domain.Enums;

public enum TipoComprobante
{
    Factura = 1,
    Boleta = 2,
    NotaCredito = 3,
    NotaDebito = 4,
    Recibo = 5,
    GuiaRemision = 6
}
